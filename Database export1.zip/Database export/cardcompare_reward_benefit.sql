-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: cardcompare
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `reward_benefit`
--

LOCK TABLES `reward_benefit` WRITE;
/*!40000 ALTER TABLE `reward_benefit` DISABLE KEYS */;
INSERT INTO `reward_benefit` VALUES (1,'N/A',NULL,'N/A','N/A','N/A','N/A','Flat ₹200 Discount on Swiggy Dineout (Minimum Order Value ₹2,000). Valid Twice Each Month','Rewards processed as CashPoints, 1 CP = Re. 1 while redeeming against statement balance of credit card and 1 CP = Rs. 0.30 while redeeming against products and vouchers in the product catalogue, and against flight/hotel booking.','5% Cashback Up to 1,000 CashPoints at Top Ten Online Merchants in India. 1% Cashback Up to 1,000 CashPoints on Other Eligible Spends','N/A','1,000 CashPoints','N/A'),(2,'N/A',NULL,'N/A','N/A','N/A','N/A','N/A','Cashback earned with the card will be automatically credited to next month’s statement.','5% Cashback for Online Spends. 1% Cashback for Offline Spends. Maximum Cashback of ₹5,000 in a Statement Cycle','N/A','N/A','N/A'),(3,'4 complimentary access to domestic lounges every year (1 per quarter).',NULL,'N/A','N/A','Fraud Liability Cover of ₹1 Lakh','N/A','Accelerated 10 Reward Points for Every ₹100 Spent on Dining and Movie Tickets.','Redeem RPs for Fuel at BPCL Stations, Against Statement, or for Products and Vouchers With SBI','25 Reward Points/₹100 Spent at BPCL Fuel Stations (Reward Rate = 7.25%), 10 RPs/₹100 Spent on Groceries, Departmental Stores, and Movie Tickets, and 1 Reward Point for Every ₹100 Spent on All Other Expenditures','Complimentary domestic airport lounge visits','6,000 Bonus Reward Points Worth ₹1,500','N/A'),(4,'N/A',NULL,'N/A','N/A','N/A','N/A','N/A','Redeem RPs for Vouchers, Statement Credit and More. 1 RP = ₹0.25','10X Reward Points on Partner Brands (Apollo 24×7, BookMyShow, Cleartrip, Dominos, IGP, Myntra, Netmeds, and Yatra), 5X Reward Points on Online Purchases, and 1 Reward Point/₹100 Spent on Other Purchases','N/A','Amazon Gift Card Worth ₹500','N/A'),(5,'1 Free Domestic Airport Lounge Access Every Quarter (4 Each Year)',NULL,'N/A','N/A','N/A','N/A','15% Up to ₹500 Off at Partner Restaurants With Axis Bank Dining Delights Program','N/A','5% Cashback on Flipkart & Cleartrip, 4% Cashback on Preferred Partners (Swiggy, Uber, PVR, and cult.fit), and 1% Cashback on All Other Spends','Accelerated Cashback (4%) on Uber Rides','Introductory Benefits Worth Rs. 600 on Card Issuance','N/A'),(6,'8 per annum with Silver Tier, 12 per annum with Gold Tier and 18 per annum with Platinum Tier',NULL,'N/A','N/A','N/A','4 per annum under Silver Tier, 6 per annum under Gold Tier and 12 per annum under Platinum Tier','Discounts of up to 25% up to Rs. 800 at partner restaurants via EazyDiner. Offer valid twice per month on a minimum order value of Rs. 2000.','Edge Miles can be transferred to international and domestic loyalty program partners for airlines and hotels.','5 Edge Miles for every Rs. 100 spent on travel spends, 2 Edge Miles for every Rs. 100 spent on all other transactions excluding spends on Hotels, Airlines, and TRAVEL EDGE Portal','Accelerated EDGE Mile Earning','2,500 Edge Miles on Completing 1 Transaction Within 30 Days of Card Issuance','N/A');
/*!40000 ALTER TABLE `reward_benefit` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-28 21:23:42
