-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: cardcompare
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `fees_and_charge`
--

LOCK TABLES `fees_and_charge` WRITE;
/*!40000 ALTER TABLE `fees_and_charge` DISABLE KEYS */;
INSERT INTO `fees_and_charge` VALUES (1,'N/A','2.5% of the transaction amount, subject to a minimum fee of Rs. 500','3.5% + GST','A 1% Fuel surcharge is waived if you spend between Rs. 400 and Rs. 5,000 on fuel (Max Rs. 250 per statement cycle)','3.75% Per Month (45% Annually)','₹1,000 + GST','₹1,000 + GST','₹50 + GST Per Cash Redemption Request. ₹99 + GST for Other Redemptions','The renewal fee is waived off if the cardholder spends Rs. 1 Lakh or more in the previous year.'),(2,'N/A','2.5% of the amount withdrawn or a minimum charge of Rs. 500.','3.5% of the international transaction','1% fuel surcharge waiver for transactions between Rs. 500 and Rs. 3,000 at petrol pumps across India. (waiver capped at Rs. 100 per statement)','3.75% per month (45% per annum)','₹999 + GST','₹999 + GST','₹99','The annual fee can be waived on spending Rs. 2,00,000 or more in the previous year.'),(3,'N/A','2.5% of the withdrawn amount (subject to a minimum charge of Rs. 500)','3.5% of the transaction amount','1% fuel surcharge waiver on transactions up to Rs. 4,000 (max waiver of Rs. 100 in a month)','3.75% Per Month (45% Per Annum)','Rs. 1,499 + GST','Rs. 1,499 + GST','Rs. 99 (plus applicable taxes) per redemption request.','Next year\'s renewal fee waived on annual expenditure of Rs. 2 lakh.'),(4,'N/A','2.5% of the withdrawal amount or a minimum fee of Rs. 500','3.5%','1% fuel surcharge waived on fuel transactions from Rs. 500 to Rs. 3,000 (max waiver capped at Rs. 100 per month)','3.75% Per Month (45% Yearly)','₹499 + GST','₹499 + GST','₹99 + GST','Annual Charges Waived on Spends of ₹1 Lakh'),(5,'N/A','2.5% (Minimum of ₹500)','3.5%','1% surcharge for fuel purchases between Rs. 400 & Rs. 4,000 (max waiver capped at Rs. 400/month).','3.75% Per Month (55.55% annually)','Rs. 500 + GST','Rs. 500 + GST','Nil','Annual fee waived on spends of Rs. 3.5 lakhs'),(6,'N/A','2.5% of the withdrawal amount (subject to min charge of Rs. 500)','3.5% of the transaction amount','1% Waiver for Fuel Transactions Between ₹400 and ₹4,000 (Capped at ₹400 Per Statement Cycle)','3.75% Per Month (55.55% Annually)','Rs. 5,000 + GST','Rs. 5,000 + GST','₹99 + GST for Redemption of EDGE Miles and ₹199 + GST for Conversion of EDGE Miles to Partner Points','N/A');
/*!40000 ALTER TABLE `fees_and_charge` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-28 21:23:43
